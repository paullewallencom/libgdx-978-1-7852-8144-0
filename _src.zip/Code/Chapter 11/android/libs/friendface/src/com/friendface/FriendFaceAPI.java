package com.friendface;

/**
 * Created by James on 17/06/2015.
 */
public class FriendFaceAPI {


    public void postScore(String name, int score) {
        //Some code here that would contact their service
        //This is outside the scope of the book as we are just interested in calling this method.
    }
}
