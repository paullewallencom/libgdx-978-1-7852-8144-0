package com.packt.game;

/**
 * Created by James on 17/06/2015.
 */
public interface ScoreHandler {
    void postScore(String name, int score);
}
